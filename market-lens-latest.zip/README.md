# Market Lens｜交易雷達

純本機 Expo / React Native / TypeScript 行情技術分析原型。

## 已完成

- 股票、期貨、金屬、匯率與美股商品搜尋／切換（目前為本地模擬資料）
- 15 分 K 主圖與 1 分、5 分、1 小時、日線切換介面
- SMA 週期可輸入
- 主力買賣成本提示：每日開盤 15 分 K 使用 `(開盤 + 高點 + 低點) / 3`
- 費波黃金切割率 0.236 / 0.500 / 0.786 顯示切換
- SMC 標記：CHOCH、OB、BOS、TP1、TP2
- 委賣／委買掛單量切換與市場深度視覺化
- 深色交易終端風格，適配手機直向畫面

## 啟動

```bash
npm install
npm run start
```

- Android 實機：手機安裝 Expo Go，掃描 Metro QR Code
- Android 模擬器：`npm run android`
- 瀏覽器預覽：`npm run web`

## 接真實行情 API

目前 `App.tsx` 內的 `instruments` 與 `candles` 是 UI 驗證用假資料。後續可將它們替換為 WebSocket / REST 資料層；建議將行情來源封裝到 `services/marketData.ts`，並以商品代碼、週期與深度資料分開管理。
