
## Risk Engine 風控核心

`risk_engine.py` 是獨立的交易前風控模組，**不匯入 `kgisuperpy`，也不會直接送出委託**。它只接受標準化的 `OrderIntent`、帳戶快照與商品規則，回傳 `RiskDecision`。

涵蓋檢查：

- `TRADING_ENABLED` 預設為 false
- bridge 健康與 KGI session 驗證
- 商品白名單
- 台指期口數上限
- 限價與止損的最小跳動檢查
- 買賣方向與止損位置
- Tick／五檔資料 freshness
- 交易時段
- 單筆風險、總未平倉風險與單日損失
- request ID／signal ID 去重
- 每分鐘送單速率
- latched circuit breaker 與人工 reset

商品乘數、點值、最小跳動、費用、最大口數與交易時段不可使用猜測值；必須從已核對的凱基／交易所設定注入 `ContractRule` 與 `RiskConfig`。

### 執行測試

```bash
cd kgi-bridge
.venv/bin/python -m unittest -v test_risk_engine.py
```

目前測試包含 10 個案例，涵蓋安全預設、合法訂單、過期行情、重複請求、價格／止損、曝險、單日損失、熔斷、未知商品與速率限制。

### 接入順序

1. `Signal Engine` 只產生 `OrderIntent`，不可呼叫 KGI。
2. `RiskEngine.validate()` 回傳 `approved` 與拒絕原因。
3. UI 顯示 `RiskDecision` 與完整訂單草稿。
4. 人工確認並產生一次性 nonce。
5. 未來的 `Execution Gateway` 再檢查 nonce、draft TTL、`TRADING_ENABLED` 與對帳狀態，才可考慮呼叫 `FutOrder.create_order()`。

Risk Engine 通過不等於成交，也不等於可以直接送單；它只是必要的交易前閘門。
