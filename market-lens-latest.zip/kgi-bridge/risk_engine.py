"""Pre-trade risk engine for KGI domestic futures.

This module is deliberately independent from kgisuperpy and has no order-submission
side effects. It validates an OrderIntent and returns a structured decision that an
execution gateway may consume only after its own confirmation/nonce checks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
from typing import Literal, Mapping, Sequence

Action = Literal["buy", "sell"]
Price = Decimal | Literal["MKT"]


@dataclass(frozen=True)
class ContractRule:
    symbol: str
    tick_size: Decimal
    point_value: Decimal
    max_contracts: int


@dataclass(frozen=True)
class TradingWindow:
    start: time
    end: time
    weekdays: frozenset[int] = frozenset({0, 1, 2, 3, 4})

    def contains(self, value: datetime) -> bool:
        local = value.astimezone(timezone.utc)
        weekday = local.weekday()
        if weekday not in self.weekdays:
            return False
        now = local.time().replace(tzinfo=None)
        if self.start <= self.end:
            return self.start <= now <= self.end
        # Overnight session: e.g. 15:00 to 05:00 UTC.
        return now >= self.start or now <= self.end


@dataclass(frozen=True)
class RiskConfig:
    enabled: bool = False
    max_contracts: int = 1
    max_risk_per_trade: Decimal = Decimal("0")
    max_daily_loss: Decimal = Decimal("0")
    max_open_risk: Decimal = Decimal("0")
    max_slippage_ticks: int = 2
    max_orders_per_minute: int = 2
    stale_quote_seconds: int = 5
    fee_per_contract: Decimal = Decimal("0")
    slippage_cost_per_tick: Decimal = Decimal("0")
    require_stop: bool = True
    allowed_symbols: Mapping[str, ContractRule] = field(default_factory=dict)
    windows: Sequence[TradingWindow] = field(default_factory=tuple)


@dataclass(frozen=True)
class OrderIntent:
    request_id: str
    signal_id: str
    strategy_id: str
    symbol: str
    action: Action
    quantity: int
    price: Price
    stop_price: Decimal | None
    quote_last: Decimal | None
    quote_timestamp: datetime
    created_at: datetime
    time_in_force: Literal["ROD", "IOC", "FOK"] = "ROD"


@dataclass(frozen=True)
class AccountSnapshot:
    realized_pnl_today: Decimal
    open_risk: Decimal
    available_equity: Decimal | None = None
    authenticated: bool = False
    bridge_healthy: bool = False


@dataclass(frozen=True)
class RiskDecision:
    approved: bool
    requires_confirmation: bool
    reasons: tuple[str, ...]
    estimated_risk: Decimal = Decimal("0")
    projected_open_risk: Decimal = Decimal("0")


class CircuitBreaker:
    """Latched breaker. It never clears itself after a reconnect or restart."""

    def __init__(self) -> None:
        self._reason: str | None = None

    @property
    def active(self) -> bool:
        return self._reason is not None

    @property
    def reason(self) -> str | None:
        return self._reason

    def trip(self, reason: str) -> None:
        self._reason = reason

    def reset(self, operator_ack: str) -> None:
        if operator_ack != "RESET-RISK-BREAKER":
            raise ValueError("manual operator acknowledgement required")
        self._reason = None


class RiskEngine:
    def __init__(self, config: RiskConfig, now: datetime | None = None) -> None:
        self.config = config
        self.now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        self.breaker = CircuitBreaker()
        self._processed_requests: set[str] = set()
        self._processed_signals: set[str] = set()
        self._order_times: list[datetime] = []

    def validate(self, intent: OrderIntent, account: AccountSnapshot) -> RiskDecision:
        reasons: list[str] = []
        rule = self.config.allowed_symbols.get(intent.symbol)
        quote_age = self._age_seconds(intent.quote_timestamp)
        estimated = Decimal("0")

        if not self.config.enabled:
            reasons.append("TRADING_ENABLED is false")
        if self.breaker.active:
            reasons.append(f"circuit breaker active: {self.breaker.reason}")
        if not account.bridge_healthy:
            reasons.append("bridge is not healthy")
        if not account.authenticated:
            reasons.append("KGI session is not authenticated")
        if rule is None:
            reasons.append("symbol is not allowlisted")
        if intent.request_id in self._processed_requests:
            reasons.append("duplicate request_id")
        if intent.signal_id in self._processed_signals:
            reasons.append("duplicate signal_id")
        if intent.action not in ("buy", "sell"):
            reasons.append("invalid action")
        if intent.quantity <= 0:
            reasons.append("quantity must be positive")
        if intent.quantity > self.config.max_contracts:
            reasons.append("quantity exceeds global max_contracts")
        if rule and intent.quantity > rule.max_contracts:
            reasons.append("quantity exceeds symbol max_contracts")
        if intent.time_in_force not in ("ROD", "IOC", "FOK"):
            reasons.append("invalid time_in_force")
        if quote_age < 0 or quote_age > self.config.stale_quote_seconds:
            reasons.append("quote is stale or timestamp is in the future")
        if self.config.windows and not any(window.contains(intent.created_at) for window in self.config.windows):
            reasons.append("outside configured trading window")
        if len(self._recent_order_times()) >= self.config.max_orders_per_minute:
            reasons.append("order rate limit exceeded")

        if rule:
            estimated = self._estimate_risk(intent, rule)
            if intent.price != "MKT":
                try:
                    price = Decimal(intent.price)
                    if price <= 0 or price % rule.tick_size != 0:
                        reasons.append("limit price is not aligned to tick_size")
                    if intent.quote_last is not None and abs(price - intent.quote_last) > rule.tick_size * self.config.max_slippage_ticks:
                        reasons.append("limit price exceeds slippage bound")
                except (InvalidOperation, TypeError):
                    reasons.append("invalid limit price")
            elif intent.quote_last is None:
                reasons.append("market order requires a fresh quote")

            if self.config.require_stop and intent.stop_price is None:
                reasons.append("stop_price is required")
            if intent.stop_price is not None:
                try:
                    stop = Decimal(intent.stop_price)
                    reference = Decimal(intent.price) if intent.price != "MKT" else intent.quote_last
                    if reference is None:
                        reasons.append("cannot validate stop without reference price")
                    elif (intent.action == "buy" and stop >= reference) or (intent.action == "sell" and stop <= reference):
                        reasons.append("stop_price is on the wrong side of entry")
                    elif stop % rule.tick_size != 0:
                        reasons.append("stop_price is not aligned to tick_size")
                except (InvalidOperation, TypeError):
                    reasons.append("invalid stop_price")

            if self.config.max_risk_per_trade <= 0 or estimated > self.config.max_risk_per_trade:
                reasons.append("estimated risk exceeds per-trade limit")
            projected = account.open_risk + estimated
            if self.config.max_open_risk <= 0 or projected > self.config.max_open_risk:
                reasons.append("projected open risk exceeds limit")
            if account.realized_pnl_today - estimated <= -self.config.max_daily_loss:
                reasons.append("projected daily loss exceeds limit")
        else:
            projected = account.open_risk

        approved = not reasons
        if approved:
            self._processed_requests.add(intent.request_id)
            self._processed_signals.add(intent.signal_id)
            self._order_times.append(self.now)
        return RiskDecision(approved, approved, tuple(reasons), estimated, projected)

    def trip_on_loss(self, realized_pnl_today: Decimal) -> None:
        if self.config.max_daily_loss > 0 and realized_pnl_today <= -self.config.max_daily_loss:
            self.breaker.trip("daily loss limit reached")

    def trip(self, reason: str) -> None:
        self.breaker.trip(reason)

    def _recent_order_times(self) -> list[datetime]:
        cutoff = self.now - timedelta(minutes=1)
        self._order_times = [value for value in self._order_times if value >= cutoff]
        return self._order_times

    def _age_seconds(self, timestamp: datetime) -> float:
        value = timestamp if timestamp.tzinfo else timestamp.replace(tzinfo=timezone.utc)
        return (self.now - value.astimezone(timezone.utc)).total_seconds()

    def _estimate_risk(self, intent: OrderIntent, rule: ContractRule) -> Decimal:
        if intent.stop_price is None:
            return Decimal("Infinity")
        entry = Decimal(intent.price) if intent.price != "MKT" else intent.quote_last
        if entry is None:
            return Decimal("Infinity")
        distance = abs(entry - Decimal(intent.stop_price))
        return distance * rule.point_value * intent.quantity + self.config.fee_per_contract * intent.quantity + self.config.slippage_cost_per_tick * self.config.max_slippage_ticks * intent.quantity
