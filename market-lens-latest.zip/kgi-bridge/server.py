"""KGI read-only quote bridge for Market Lens.

Run this on the machine where KGI CA components and credentials are installed.
No order/cancel endpoints are intentionally exposed in this first phase.
"""
from __future__ import annotations

import json
import os
import threading
import time
import ctypes.util
import importlib.util
from collections import defaultdict
from typing import Any

from flask import Flask, jsonify, request, Response, send_file

app = Flask(__name__)
_lock = threading.RLock()
_latest: dict[str, dict[str, Any]] = {}
_events: list[dict[str, Any]] = []
_api = None
_started = False


def _plain(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if hasattr(value, "__dict__"):
        return {str(k): _plain(v) for k, v in vars(value).items() if not str(k).startswith("_")}
    return str(value)


def _save(kind: str, market: str, symbol: str, payload: Any) -> None:
    item = {
        "kind": kind,
        "market": market,
        "symbol": symbol,
        "receivedAt": time.time(),
        "data": _plain(payload),
    }
    key = f"{market}:{symbol}:{kind}"
    with _lock:
        _latest[key] = item
        _events.append(item)
        del _events[:-500]


def _callback_factory(kind: str, market: str, symbol: str):
    def callback(data):
        _save(kind, market, symbol, data)
    return callback


def start_kgi() -> None:
    """Login and register read-only subscriptions from environment variables."""
    global _api, _started
    if _started:
        return
    person_id = os.environ.get("KGI_PERSON_ID")
    person_pwd = os.environ.get("KGI_PERSON_PWD")
    if not person_id or not person_pwd:
        raise RuntimeError("Missing KGI_PERSON_ID / KGI_PERSON_PWD environment variables")

    # Import lazily so /health still explains configuration errors without importing CA.
    from kgisuperpy import login

    simulation = os.environ.get("KGI_SIMULATION", "true").lower() == "true"
    _api = login(person_id=person_id, person_pwd=person_pwd, simulation=simulation)
    if not hasattr(_api, "Quote") or not hasattr(_api, "FutQuote"):
        raise RuntimeError("KGI login completed without quote managers; check CA/API permissions")

    stock_symbols = [x.strip() for x in os.environ.get("KGI_STOCK_SYMBOLS", "2330").split(",") if x.strip()]
    futures_symbols = [x.strip() for x in os.environ.get("KGI_FUTURES_SYMBOLS", "TXF").split(",") if x.strip()]

    for symbol in stock_symbols:
        _api.Quote.set_cb_tick(_callback_factory("tick", "twse", symbol))
        _api.Quote.set_cb_bidask(_callback_factory("bidask", "twse", symbol))
        _api.Quote.set_cb_kbar(_callback_factory("kbar", "twse", symbol))
        _api.Quote.subscribe_tick(symbol)
        _api.Quote.subscribe_bidask(symbol)
        _api.Quote.subscribe_kbar(symbol, minute=15)

    for symbol in futures_symbols:
        _api.FutQuote.set_cb_tick(_callback_factory("tick", "futures", symbol))
        _api.FutQuote.set_cb_bidask(_callback_factory("bidask", "futures", symbol))
        _api.FutQuote.subscribe_tick(symbol)
        _api.FutQuote.subscribe_bidask(symbol)

    _started = True


@app.get("/panel")
def panel():
    return send_file(os.path.join(os.path.dirname(__file__), "panel.html"), mimetype="text/html")


@app.get("/api/diagnostics")
def diagnostics():
    importable = False
    import_error = None
    if importlib.util.find_spec("kgisuperpy") is not None:
        try:
            import kgisuperpy  # noqa: F401
            importable = True
        except Exception as exc:
            import_error = type(exc).__name__
    library_candidates = [
        ctypes.util.find_library("CGCrypt"),
        "/usr/lib/libCGCrypt.so",
        "/usr/lib/x86_64-linux-gnu/libCGCrypt.so",
        "/lib/x86_64-linux-gnu/libCGCrypt.so",
        "/lib64/libCGCrypt.so",
    ]
    library_path = next((p for p in library_candidates if p and (os.path.isabs(p) and os.path.exists(p) or not os.path.isabs(p))), None)
    return jsonify({
        "ok": True,
        "kgisuperpy_installed": importlib.util.find_spec("kgisuperpy") is not None,
        "kgisuperpy_importable": importable,
        "import_error_type": import_error,
        "cgcrypt_found": library_path is not None,
        "credentials_configured": bool(os.environ.get("KGI_PERSON_ID") and os.environ.get("KGI_PERSON_PWD")),
        "kgi_started": _started,
        "trading_enabled": False,
        "message": "診斷只回傳存在性與狀態，不會輸出帳號、密碼或憑證內容。",
    })


@app.get("/health")
def health():
    return jsonify({"ok": True, "kgiStarted": _started, "mode": "read-only", "latestCount": len(_latest)})


@app.post("/api/start")
def start():
    try:
        start_kgi()
        return jsonify({"ok": True, "kgiStarted": True, "mode": "read-only"})
    except Exception as exc:
        return jsonify({"ok": False, "error": type(exc).__name__, "message": str(exc)}), 503


@app.get("/api/latest")
def latest():
    market = request.args.get("market")
    symbol = request.args.get("symbol")
    with _lock:
        data = list(_latest.values())
    if market:
        data = [x for x in data if x["market"] == market]
    if symbol:
        data = [x for x in data if x["symbol"] == symbol]
    return jsonify({"ok": True, "data": data})


@app.get("/api/events")
def events():
    after = float(request.args.get("after", "0"))
    with _lock:
        data = [x for x in _events if x["receivedAt"] > after]
    return jsonify({"ok": True, "data": data})


@app.get("/api/stream")
def stream():
    def generate():
        cursor = 0.0
        while True:
            with _lock:
                items = [x for x in _events if x["receivedAt"] > cursor]
            for item in items:
                cursor = max(cursor, item["receivedAt"])
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
            time.sleep(0.5)
    return Response(generate(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


if __name__ == "__main__":
    app.run(host=os.environ.get("BRIDGE_HOST", "127.0.0.1"), port=int(os.environ.get("BRIDGE_PORT", "8765")), threaded=True)
