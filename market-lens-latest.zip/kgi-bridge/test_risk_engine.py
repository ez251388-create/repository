from datetime import datetime, time, timedelta, timezone
from decimal import Decimal
import unittest

from risk_engine import AccountSnapshot, ContractRule, OrderIntent, RiskConfig, RiskEngine, TradingWindow


NOW = datetime(2026, 10, 8, 2, 0, tzinfo=timezone.utc)
RULE = ContractRule("TXF202610", Decimal("1"), Decimal("200"), 2)
ACCOUNT = AccountSnapshot(Decimal("0"), Decimal("0"), Decimal("500000"), True, True)


def intent(**overrides):
    data = dict(
        request_id="req-1", signal_id="sig-1", strategy_id="test",
        symbol="TXF202610", action="buy", quantity=1,
        price=Decimal("23000"), stop_price=Decimal("22990"),
        quote_last=Decimal("23000"), quote_timestamp=NOW,
        created_at=NOW, time_in_force="ROD",
    )
    data.update(overrides)
    return OrderIntent(**data)


def config(**overrides):
    data = dict(
        enabled=True, max_contracts=2,
        max_risk_per_trade=Decimal("5000"), max_daily_loss=Decimal("10000"),
        max_open_risk=Decimal("8000"), max_slippage_ticks=2,
        max_orders_per_minute=2, stale_quote_seconds=5,
        fee_per_contract=Decimal("50"), slippage_cost_per_tick=Decimal("10"),
        require_stop=True, allowed_symbols={RULE.symbol: RULE},
        windows=(TradingWindow(time(0), time(23, 59)),),
    )
    data.update(overrides)
    return RiskConfig(**data)


class RiskEngineTests(unittest.TestCase):
    def test_safe_default_rejects(self):
        engine = RiskEngine(RiskConfig(), NOW)
        decision = engine.validate(intent(), ACCOUNT)
        self.assertFalse(decision.approved)
        self.assertIn("TRADING_ENABLED is false", decision.reasons)

    def test_valid_order_is_approved_but_requires_confirmation(self):
        engine = RiskEngine(config(), NOW)
        decision = engine.validate(intent(), ACCOUNT)
        self.assertTrue(decision.approved)
        self.assertTrue(decision.requires_confirmation)
        self.assertEqual(decision.estimated_risk, Decimal("2070"))

    def test_stale_quote_is_rejected(self):
        engine = RiskEngine(config(), NOW)
        decision = engine.validate(intent(quote_timestamp=NOW - timedelta(seconds=6)), ACCOUNT)
        self.assertIn("quote is stale or timestamp is in the future", decision.reasons)

    def test_duplicate_request_is_rejected(self):
        engine = RiskEngine(config(), NOW)
        self.assertTrue(engine.validate(intent(), ACCOUNT).approved)
        decision = engine.validate(intent(), ACCOUNT)
        self.assertIn("duplicate request_id", decision.reasons)
        self.assertIn("duplicate signal_id", decision.reasons)

    def test_price_and_stop_must_match_tick_and_direction(self):
        engine = RiskEngine(config(), NOW)
        decision = engine.validate(intent(price=Decimal("23000.5"), stop_price=Decimal("23001")), ACCOUNT)
        self.assertIn("limit price is not aligned to tick_size", decision.reasons)
        self.assertIn("stop_price is on the wrong side of entry", decision.reasons)

    def test_exposure_limit_is_rejected(self):
        engine = RiskEngine(config(max_open_risk=Decimal("1000")), NOW)
        decision = engine.validate(intent(), ACCOUNT)
        self.assertIn("projected open risk exceeds limit", decision.reasons)

    def test_daily_loss_limit_is_rejected(self):
        engine = RiskEngine(config(), NOW)
        account = AccountSnapshot(Decimal("-9000"), Decimal("0"), Decimal("500000"), True, True)
        decision = engine.validate(intent(), account)
        self.assertIn("projected daily loss exceeds limit", decision.reasons)

    def test_breaker_is_latched_until_manual_ack(self):
        engine = RiskEngine(config(), NOW)
        engine.trip("manual emergency stop")
        decision = engine.validate(intent(), ACCOUNT)
        self.assertIn("circuit breaker active: manual emergency stop", decision.reasons)
        with self.assertRaises(ValueError):
            engine.breaker.reset("wrong")
        engine.breaker.reset("RESET-RISK-BREAKER")
        self.assertFalse(engine.breaker.active)

    def test_unknown_symbol_is_rejected(self):
        engine = RiskEngine(config(), NOW)
        decision = engine.validate(intent(symbol="UNKNOWN"), ACCOUNT)
        self.assertIn("symbol is not allowlisted", decision.reasons)

    def test_order_rate_limit_is_rejected(self):
        engine = RiskEngine(config(max_orders_per_minute=1), NOW)
        self.assertTrue(engine.validate(intent(), ACCOUNT).approved)
        decision = engine.validate(intent(request_id="req-2", signal_id="sig-2"), ACCOUNT)
        self.assertIn("order rate limit exceeded", decision.reasons)


if __name__ == "__main__":
    unittest.main()
