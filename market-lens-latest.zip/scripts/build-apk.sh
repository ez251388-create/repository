#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
npm ci
npx expo prebuild --platform android --non-interactive --clean
(
  cd android
  ./gradlew assembleDebug --no-daemon
)

APK="android/app/build/outputs/apk/debug/app-debug.apk"
OUT="market-lens-debug-$(date +%Y%m%d-%H%M%S).apk"
cp "$APK" "$OUT"
printf '\nAPK 已產生：%s/%s\n' "$PWD" "$OUT"
