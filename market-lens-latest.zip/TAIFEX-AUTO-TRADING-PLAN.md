# 台指期自動下單與風險控制規劃

> 本文件是凱基 CA 驗證成功後的實作藍圖。預設先做只讀、模擬與人工確認；任何實盤委託都必須通過明確的本機開關、風控閘門與使用者確認。SMC、Symmetrical Triangle、BOS、CHOCH、OB、FVG 只產生訊號，**不得直接觸發下單**。

## 1. 目標與邊界

### 目標

- 將凱基台指期即時報價、五檔、K 線、委託／成交回報接入本機 bridge。
- 以可測試的計算模組產生策略訊號與 `OrderIntent`。
- 在送到凱基前執行價格、口數、曝險、交易時段、資料新鮮度與重複單檢查。
- 具備斷線保護、緊急停止、審計紀錄與可回放測試。

### 明確不做

- 不把帳密、CA、token 或下單權限放入 Android App。
- 不用技術指標自動決定是否突破風控。
- 不把模擬行情、回測結果或預估保證金當成實盤保證。
- 不在尚未核對凱基 SDK 交易回報欄位時猜測成交／撤單狀態。

## 2. 建議架構

```text
凱基 API / CA
      │
      ▼
KGI Adapter（只處理官方 SDK）
      │  tick / bidask / kbar / order-report
      ▼
Market Normalizer + Freshness Guard
      │
      ├── Chart & SMC Calculator
      │       └── Signal / OrderIntent（不送單）
      │
      ├── Position & Account Cache
      │
      ▼
Risk Engine（硬性拒絕）
      │
      ▼
Order Preview + Human Confirm
      │
      ▼
Execution Gateway（實盤開關）
      │
      ▼
KGI FutOrder.create_order()
      │
      ▼
Order / Deal Reconciler + Audit Log
```

### 模組責任

| 模組 | 可做 | 不可做 |
|---|---|---|
| KGI Adapter | 登入、訂閱、送出已核准的 SDK 呼叫、接收回報 | 解讀策略、繞過風控 |
| Normalizer | 統一 symbol、timestamp、價格、數量、狀態 | 修改原始成交結果 |
| Signal Engine | 由 K 線計算 SMA、SMC、三角形與訊號 | 直接呼叫下單 API |
| Risk Engine | 計算風險、拒絕不合規 OrderIntent | 自動放寬限制 |
| Execution Gateway | 送出已核准且未過期的訂單 | 接受未簽核或重複 request |
| Reconciler | 對照委託、成交、撤單與持倉 | 把「送出成功」當成「成交成功」 |

## 3. 分階段上線門檻

### Phase 0：憑證與只讀環境

完成條件：

- 本機 CA 與凱基 SDK 可登入。
- `/health`、`/api/diagnostics` 通過。
- 台指期 tick、五檔、15 分 K 可收到，並顯示最後回報時間。
- `KGI_SIMULATION` 與實盤環境明確分開。
- 不存在任何 order/cancel route。

### Phase 1：資料與訊號驗證

- 以真實 K 線計算 pivot、BOS、CHOCH、OB、FVG、Symmetrical Triangle。
- 每個訊號保存：symbol、bar timestamp、計算版本、輸入 K 線範圍、方向、失效條件。
- 只產生 `SignalEvent`，不產生交易副作用。
- 用歷史資料與即時資料重播比對結果。

### Phase 2：OrderDraft，不送出

- 建立台指期 `OrderDraft`。
- 執行完整風控與價格／口數驗證。
- UI 顯示完整 payload：方向、合約、口數、價格、市價／限價、ROD／IOC／FOK、止損與最大損失估算。
- 只寫入 `audit/order-drafts.jsonl`，不可呼叫 `FutOrder.create_order`。

### Phase 3：模擬執行

- 使用凱基模擬環境或本地 execution simulator。
- 模擬滑價、拒單、部分成交、斷線、重連、重複回報。
- 驗證持倉、已用風險、可用保證金與每日損益快取一致。

### Phase 4：人工確認的極小實盤

- `TRADING_ENABLED=true` 只能在本機 secret/environment 設定，不能由 App 傳入。
- 每筆訂單都要有人工確認與一次性 nonce。
- 先限定單一指定台指期商品、單一口、限價單、固定時段。
- 每日達到交易次數、損失或錯誤門檻立即停止。

### Phase 5：受控自動化

只有 Phase 0–4 全部有稽核紀錄後，才評估自動送單。即使開啟，也必須保留：最大口數、單日最大損失、單筆最大風險、連續虧損停機、資料陳舊停機、斷線停機與人工 kill switch。

## 4. 台指期 OrderIntent

```python
from dataclasses import dataclass
from typing import Literal

@dataclass(frozen=True)
class OrderIntent:
    request_id: str                 # UUID，重試不可重用
    strategy_id: str
    market: Literal["futures"]
    symbol: str                     # 以凱基實際可交易商品代碼為準
    action: Literal["buy", "sell"]
    quantity: int
    price: float | str              # 限價數值或已核對的 PriceType
    time_in_force: Literal["ROD", "IOC", "FOK"]
    stop_price: float | None
    source_bar_timestamp: str
    created_at: str
    signal_id: str
```

`OrderIntent` 不應包含密碼、CA、帳號密鑰或可直接繞過 Risk Engine 的欄位。

## 5. 風控規則

### 5.1 交易前硬性檢查

任何一項失敗就拒絕：

1. `TRADING_ENABLED` 未明確為 true。
2. bridge 未健康、CA session 未驗證或行情超過 freshness TTL。
3. 商品不在允許白名單，或合約月份與目前交易月份不一致。
4. 方向、口數、價格、最小跳動位數或交易時效不合法。
5. 當前時間不在經核對的交易時段；跨日與夜盤要獨立設定。
6. 無法取得最新持倉、可用保證金、委託與成交狀態。
7. 會造成超過單筆、單日或總曝險上限。
8. 相同 `signal_id` 或 `request_id` 已處理。
9. 計算訊號的 K 線已失效，或訊號與當前報價偏離超過允許滑價。
10. kill switch、熔斷器或連續錯誤狀態為 active。

### 5.2 風險計算

不要硬編合約乘數、保證金或跳動價值；啟動時從已核對的凱基／交易所設定載入，並在 UI 顯示來源與時間。

```text
單口止損風險
= abs(entry_price - stop_price)
  × point_value
  + 預估手續費
  + 預估滑價成本

總新增風險
= 單口止損風險 × quantity

下單後總風險
= 現有未平倉風險 + 總新增風險
```

建議先把以下值做成設定而非常數：

- `MAX_CONTRACTS`
- `MAX_RISK_PER_TRADE_TWD`
- `MAX_DAILY_LOSS_TWD`
- `MAX_OPEN_RISK_TWD`
- `MAX_SLIPPAGE_TICKS`
- `MAX_ORDERS_PER_MINUTE`
- `MAX_CONSECUTIVE_LOSSES`
- `STALE_QUOTE_SECONDS`

### 5.3 熔斷與停機

立即禁止新單，並依情況撤回未成交單：

- CA session 過期或登入失效。
- tick／五檔超過 freshness TTL。
- 行情與成交回報時間倒退或序號異常。
- bridge 與 KGI 斷線。
- 連續拒單／API 錯誤達上限。
- 單日損失達上限。
- 未知持倉或對帳不一致。
- 超過最大口數／保證金上限。
- 偵測到重複 request 或 execution state 不一致。

恢復必須是人工明確解鎖，不要讓重連程式自動解除熔斷。

## 6. 執行與回報狀態機

```text
DRAFT
  └─risk_pass─> PENDING_CONFIRM
                    ├─reject─> CANCELLED_LOCAL
                    └─confirm─> SUBMITTING
                                   ├─transport_error─> UNKNOWN_REQUIRES_RECONCILE
                                   ├─rejected─> REJECTED
                                   └─accepted─> WORKING
                                                  ├─partial─> PARTIALLY_FILLED
                                                  ├─filled─> FILLED
                                                  ├─cancelled─> CANCELLED
                                                  └─unknown─> UNKNOWN_REQUIRES_RECONCILE
```

重要原則：

- `SUBMITTING` 超時不可直接重送；先查委託與成交回報。
- `accepted` 不代表成交。
- 部分成交要重新計算剩餘口數與曝險。
- 每個狀態轉移保存原始 KGI 回報的去識別化摘要與時間。

## 7. 建議 bridge 端點

第一階段只建立不送單的端點：

```text
GET  /health
GET  /api/diagnostics
POST /api/start
GET  /api/latest
GET  /api/stream
POST /api/order/validate       # 僅回傳 OrderDraft 風控結果
```

通過模擬測試後，才在本機受保護地加入：

```text
POST /api/order/confirm        # 需要一次性 nonce 與人工確認
POST /api/order/submit         # 只接受已簽核、未過期的 draft
POST /api/order/reconcile      # 查詢委託／成交／持倉並修正未知狀態
POST /api/risk/kill-switch
```

不要讓 Android App 直接呼叫 KGI SDK；所有交易路由都要在 bridge 的 localhost／可信 LAN 上，並加入來源限制、request id、audit log 與速率限制。

## 8. 測試矩陣

### 單元測試

- 價格跳動與合法價格格式。
- 口數、方向、ROD／IOC／FOK 映射。
- 止損距離、點值、手續費與滑價計算。
- 最大單筆／單日／總曝險限制。
- pivot、BOS、CHOCH、OB、FVG、三角形計算。
- request id 與 signal id 去重。

### 整合測試

- 模擬 login 成功／失敗／CA 缺少。
- tick、五檔、K 線 callback 正常與格式異常。
- KGI 接受、拒絕、部分成交、成交、撤單回報。
- 網路斷線後不重複送單。
- 重啟 bridge 後能以 reconciliation 恢復狀態。

### 上線前演練

- 紙上交易至少一段完整交易時段。
- 模擬夜盤、跨日、換月與流動性不足。
- 人工按下 kill switch，確認禁止新單。
- 檢查帳戶持倉、委託、成交與本地帳本可對帳。
- 由使用者在本機看到 exact payload 後，才批准最小實盤測試。

## 9. 實作順序

1. 將現有 `server.py` 拆成 `kgi_adapter.py`、`normalizer.py`、`risk_engine.py`、`execution.py`、`reconcile.py`。
2. 先建立 `POST /api/order/validate`，永遠不送 KGI。
3. 加入模擬 broker 與完整狀態機測試。
4. 加入 `OrderDraft` 人工確認 UI，不加入自動送單。
5. 核對凱基 `FutOrder.create_order(action, symbol, qty, price, time_in_force)` 的 enum 與實際回報欄位。
6. 只在本機設定 `TRADING_ENABLED=true` 後加入一次性 confirm／submit 路徑。
7. 以單一商品、單一口、限價單進行人工確認的實盤驗證。
8. 通過對帳、熔斷與 kill switch 演練後，再考慮受控自動化。

## 10. 上線前必須取得的資訊

以下項目不可用猜測值替代：

- 實際台指期商品代碼與月份格式。
- 台指期點值、最小跳動、保證金與手續費來源。
- 凱基環境的帳戶／分公司／交易市場映射。
- `Action`、`TimeInForce`、`PriceType` 的實際 enum。
- 委託、成交、撤單與持倉回報欄位。
- 夜盤與日盤交易時段規則。
- CA session 的有效期與重登入行為。

未完成上述核對前，系統只能停在行情、訊號、OrderDraft 與模擬執行階段。
