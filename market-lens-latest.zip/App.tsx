import { StatusBar } from 'expo-status-bar';
import React, { useMemo, useState } from 'react';
import {
  Dimensions,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import Svg, { Circle, Line, Path, Rect, Text as SvgText } from 'react-native-svg';

type Candle = { open: number; high: number; low: number; close: number; volume: number };

const palette = {
  bg: '#07131b',
  panel: '#0d2029',
  panel2: '#102a34',
  line: '#1d3a44',
  text: '#e8f3f2',
  muted: '#7b9a9e',
  cyan: '#43d7c8',
  green: '#38d996',
  red: '#ff6d76',
  amber: '#f5c96a',
  violet: '#9c8cff',
};

const instruments = [
  { symbol: 'TXF', name: '臺指期', price: '23,184', change: '+126', pct: '+0.55%', color: palette.green },
  { symbol: '2330', name: '台積電', price: '1,080.00', change: '+15.00', pct: '+1.41%', color: palette.green },
  { symbol: 'XAUUSD', name: '黃金現貨', price: '3,861.20', change: '-8.40', pct: '-0.22%', color: palette.red },
  { symbol: 'USDTWD', name: '美元/台幣', price: '30.668', change: '+0.021', pct: '+0.07%', color: palette.green },
  { symbol: 'NQ1!', name: 'Nasdaq 期貨', price: '24,981.50', change: '+82.25', pct: '+0.33%', color: palette.green },
];

const candles: Candle[] = [
  { open: 66, high: 54, low: 73, close: 59, volume: 22 }, { open: 59, high: 50, low: 65, close: 53, volume: 29 },
  { open: 53, high: 46, low: 58, close: 48, volume: 25 }, { open: 48, high: 51, low: 63, close: 60, volume: 31 },
  { open: 60, high: 54, low: 68, close: 56, volume: 38 }, { open: 56, high: 42, low: 59, close: 45, volume: 44 },
  { open: 45, high: 39, low: 51, close: 41, volume: 34 }, { open: 41, high: 33, low: 46, close: 36, volume: 37 },
  { open: 36, high: 39, low: 49, close: 46, volume: 52 }, { open: 46, high: 43, low: 58, close: 54, volume: 45 },
  { open: 54, high: 47, low: 56, close: 49, volume: 33 }, { open: 49, high: 36, low: 52, close: 39, volume: 55 },
  { open: 39, high: 29, low: 44, close: 32, volume: 60 }, { open: 32, high: 31, low: 45, close: 42, volume: 41 },
  { open: 42, high: 38, low: 52, close: 47, volume: 36 }, { open: 47, high: 40, low: 49, close: 44, volume: 29 },
  { open: 44, high: 25, low: 46, close: 29, volume: 57 }, { open: 29, high: 20, low: 34, close: 24, volume: 65 },
  { open: 24, high: 26, low: 38, close: 35, volume: 48 }, { open: 35, high: 27, low: 40, close: 30, volume: 39 },
];

type Pivot = { index: number; value: number };
type TrianglePattern = { highStart: Pivot; highEnd: Pivot; lowStart: Pivot; lowEnd: Pivot; apexX: number; apexY: number } | null;
type SmcPattern = { bos: { index: number; price: number; direction: 'bullish' | 'bearish' } | null; choch: { index: number; price: number; direction: 'bullish' | 'bearish' } | null; orderBlock: { index: number; top: number; bottom: number; direction: 'bullish' | 'bearish' } | null; fvg: { index: number; top: number; bottom: number; direction: 'bullish' | 'bearish' } | null };

// The demo candles use screen-space Y values. Converting to price-space keeps
// the same rules valid when real OHLC data is supplied by the KGI bridge.
function priceCandle(c: Candle) {
  return { open: 240 - c.open, high: 240 - c.high, low: 240 - c.low, close: 240 - c.close };
}

function findPivots(kind: 'high' | 'low', lookback = 2): Pivot[] {
  const result: Pivot[] = [];
  for (let i = lookback; i < candles.length - lookback; i += 1) {
    const values = candles.slice(i - lookback, i + lookback + 1).map((c) => priceCandle(c)[kind]);
    const current = values[lookback];
    const isPivot = kind === 'high' ? current === Math.max(...values) : current === Math.min(...values);
    if (isPivot && (!result.length || i - result[result.length - 1].index >= lookback)) result.push({ index: i, value: current });
  }
  return result;
}

function lineAt(a: Pivot, b: Pivot, x: number) {
  return a.value + ((b.value - a.value) * (x - a.index)) / Math.max(1, b.index - a.index);
}

function findSymmetricalTriangle(): TrianglePattern {
  const highs = findPivots('high').slice(-3);
  const lows = findPivots('low').slice(-3);
  if (highs.length < 2 || lows.length < 2) return null;
  const highStart = highs[0]; const highEnd = highs[highs.length - 1];
  const lowStart = lows[0]; const lowEnd = lows[lows.length - 1];
  const highSlope = (highEnd.value - highStart.value) / Math.max(1, highEnd.index - highStart.index);
  const lowSlope = (lowEnd.value - lowStart.value) / Math.max(1, lowEnd.index - lowStart.index);
  if (!(highSlope < -0.12 && lowSlope > 0.12 && highEnd.value > lowEnd.value)) return null;
  const left = Math.max(highEnd.index, lowEnd.index);
  const denominator = highSlope - lowSlope;
  const apexX = left + Math.max(2, Math.min(8, (lineAt(lowStart, lowEnd, left) - lineAt(highStart, highEnd, left)) / Math.max(0.01, Math.abs(denominator))));
  return { highStart, highEnd, lowStart, lowEnd, apexX, apexY: lineAt(highStart, highEnd, apexX) };
}

function findSmc(): SmcPattern {
  const highs = findPivots('high'); const lows = findPivots('low'); const latest = candles.length - 1;
  const lastHigh = highs.filter((p) => p.index < latest).at(-1); const lastLow = lows.filter((p) => p.index < latest).at(-1);
  let bos: SmcPattern['bos'] = null;
  if (lastHigh && priceCandle(candles[latest]).close > lastHigh.value) bos = { index: latest, price: lastHigh.value, direction: 'bullish' };
  if (lastLow && priceCandle(candles[latest]).close < lastLow.value) bos = { index: latest, price: lastLow.value, direction: 'bearish' };
  const priorHigh = highs.filter((p) => p.index < (lastHigh?.index ?? latest)).at(-1); const priorLow = lows.filter((p) => p.index < (lastLow?.index ?? latest)).at(-1);
  let choch: SmcPattern['choch'] = null;
  if (bos?.direction === 'bullish' && priorLow && lastLow && lastLow.value < priorLow.value) choch = { index: latest, price: lastLow.value, direction: 'bullish' };
  if (bos?.direction === 'bearish' && priorHigh && lastHigh && lastHigh.value > priorHigh.value) choch = { index: latest, price: lastHigh.value, direction: 'bearish' };
  let orderBlock: SmcPattern['orderBlock'] = null;
  if (bos) for (let i = bos.index - 1; i >= 0; i -= 1) {
    const p = priceCandle(candles[i]); const opposite = bos.direction === 'bullish' ? p.close < p.open : p.close > p.open;
    if (opposite) { orderBlock = { index: i, top: candles[i].high + 52, bottom: candles[i].low + 52, direction: bos.direction }; break; }
  }
  let fvg: SmcPattern['fvg'] = null;
  for (let i = candles.length - 1; i >= 2; i -= 1) {
    const a = priceCandle(candles[i - 2]); const c = priceCandle(candles[i]);
    if (c.low > a.high) { fvg = { index: i, top: candles[i - 2].high + 52, bottom: candles[i].low + 52, direction: 'bullish' }; break; }
    if (c.high < a.low) { fvg = { index: i, top: candles[i].high + 52, bottom: candles[i - 2].low + 52, direction: 'bearish' }; break; }
  }
  return { bos, choch, orderBlock, fvg };
}

function MiniSparkline({ positive = true }: { positive?: boolean }) {
  return (
    <Svg width={70} height={26} viewBox="0 0 70 26">
      <Path d={positive ? 'M1 21 L9 17 L16 19 L24 10 L31 14 L39 7 L47 11 L56 3 L69 6' : 'M1 5 L9 8 L16 4 L24 14 L31 12 L39 19 L47 16 L56 23 L69 20'} fill="none" stroke={positive ? palette.green : palette.red} strokeWidth="2" />
    </Svg>
  );
}

function Chart({ showFib, showSmc, showTriangle }: { showFib: boolean; showSmc: boolean; showTriangle: boolean }) {
  const width = Math.min(Dimensions.get('window').width - 32, 620);
  const height = 310;
  const chartTop = 18;
  const chartBottom = 208;
  const candleWidth = Math.max(6, (width - 36) / candles.length - 5);
  const points = candles.map((c, i) => `${18 + i * (candleWidth + 5) + candleWidth / 2},${c.close + 52}`).join(' ');
  const sma = candles.map((_, i) => `${18 + i * (candleWidth + 5) + candleWidth / 2},${56 + (i < 3 ? 8 : i < 7 ? 4 : i < 12 ? 11 : i < 16 ? 4 : 7)}`).join(' ');
  const triangle = findSymmetricalTriangle();
  const smc = findSmc();
  const xFor = (index: number) => 18 + index * (candleWidth + 5) + candleWidth / 2;
  const yForPrice = (price: number) => 292 - price;
  return (
    <Svg width={width} height={height}>
      {[0, 1, 2, 3, 4].map((i) => <Line key={i} x1="0" x2={width} y1={chartTop + i * 47} y2={chartTop + i * 47} stroke={palette.line} strokeWidth="1" />)}
      {[0, 1, 2, 3, 4].map((i) => <SvgText key={i} x={width - 29} y={22 + i * 47} fill={palette.muted} fontSize="9">{(23290 - i * 50).toLocaleString()}</SvgText>)}
      {showFib && <>
        <Line x1="18" x2={width - 34} y1="69" y2="69" stroke={palette.amber} strokeDasharray="5,4" />
        <Line x1="18" x2={width - 34} y1="116" y2="116" stroke={palette.amber} strokeDasharray="5,4" />
        <Line x1="18" x2={width - 34} y1="163" y2="163" stroke={palette.amber} strokeDasharray="5,4" />
        <SvgText x="24" y="64" fill={palette.amber} fontSize="9">0.236</SvgText><SvgText x="24" y="111" fill={palette.amber} fontSize="9">0.500</SvgText><SvgText x="24" y="158" fill={palette.amber} fontSize="9">0.786</SvgText>
      </>}
      {candles.map((c, i) => {
        const x = 18 + i * (candleWidth + 5);
        const up = c.close < c.open;
        const color = up ? palette.green : palette.red;
        return <React.Fragment key={i}><Line x1={x + candleWidth / 2} x2={x + candleWidth / 2} y1={c.high + 52} y2={c.low + 52} stroke={color} strokeWidth="1.5" /><Rect x={x} y={Math.min(c.open, c.close) + 52} width={candleWidth} height={Math.max(3, Math.abs(c.close - c.open))} rx="1" fill={color} /></React.Fragment>;
      })}
      <Path d={`M ${points.replaceAll(' ', ' L ')}`} fill="none" stroke={palette.cyan} strokeWidth="1.8" opacity="0.92" />
      <Path d={`M ${sma.replaceAll(' ', ' L ')}`} fill="none" stroke={palette.violet} strokeWidth="1.6" />
      {showTriangle && triangle && <>
        <Path d={`M ${xFor(triangle.highStart.index)} ${yForPrice(triangle.highStart.value)} L ${xFor(triangle.highEnd.index)} ${yForPrice(triangle.highEnd.value)} L ${xFor(triangle.apexX)} ${yForPrice(triangle.apexY)} L ${xFor(triangle.lowEnd.index)} ${yForPrice(triangle.lowEnd.value)} L ${xFor(triangle.lowStart.index)} ${yForPrice(triangle.lowStart.value)} Z`} fill={palette.cyan} opacity="0.035" />
        <Line x1={xFor(triangle.highStart.index)} y1={yForPrice(triangle.highStart.value)} x2={xFor(triangle.apexX)} y2={yForPrice(triangle.apexY)} stroke={palette.cyan} strokeWidth="2" strokeDasharray="6,4" />
        <Line x1={xFor(triangle.lowStart.index)} y1={yForPrice(triangle.lowStart.value)} x2={xFor(triangle.apexX)} y2={yForPrice(triangle.apexY)} stroke={palette.cyan} strokeWidth="2" strokeDasharray="6,4" />
        <Circle cx={xFor(triangle.apexX)} cy={yForPrice(triangle.apexY)} r="4" fill={palette.cyan} /><SvgText x={xFor(triangle.highStart.index)} y={Math.max(20, yForPrice(triangle.highStart.value) - 8)} fill={palette.cyan} fontSize="10">SYM TRIANGLE</SvgText>
      </>}
      {showSmc && <>
        {smc.orderBlock && <><Rect x={xFor(smc.orderBlock.index) - candleWidth} y={Math.min(smc.orderBlock.top, smc.orderBlock.bottom)} width={Math.max(44, xFor(Math.min(candles.length - 1, smc.orderBlock.index + 3)) - xFor(smc.orderBlock.index))} height={Math.abs(smc.orderBlock.bottom - smc.orderBlock.top)} fill={smc.orderBlock.direction === 'bullish' ? palette.green : palette.red} opacity="0.13" stroke={smc.orderBlock.direction === 'bullish' ? palette.green : palette.red} strokeDasharray="3,3" /><SvgText x={xFor(smc.orderBlock.index)} y={Math.min(smc.orderBlock.top, smc.orderBlock.bottom) + 14} fill={smc.orderBlock.direction === 'bullish' ? palette.green : palette.red} fontSize="10">OB</SvgText></>}
        {smc.fvg && <><Rect x={xFor(smc.fvg.index - 2)} y={Math.min(smc.fvg.top, smc.fvg.bottom)} width={Math.max(24, xFor(smc.fvg.index) - xFor(smc.fvg.index - 2))} height={Math.max(7, Math.abs(smc.fvg.bottom - smc.fvg.top))} fill={palette.violet} opacity="0.14" stroke={palette.violet} strokeDasharray="3,3" /><SvgText x={xFor(smc.fvg.index - 2) + 4} y={Math.min(smc.fvg.top, smc.fvg.bottom) + 13} fill={palette.violet} fontSize="9">FVG</SvgText></>}
        {smc.bos && <><Line x1={xFor(Math.max(0, smc.bos.index - 4))} x2={xFor(smc.bos.index)} y1={yForPrice(smc.bos.price)} y2={yForPrice(smc.bos.price)} stroke={palette.violet} strokeWidth="2" /><SvgText x={xFor(Math.max(0, smc.bos.index - 4))} y={yForPrice(smc.bos.price) - 7} fill={palette.violet} fontSize="10">BOS</SvgText></>}
        {smc.choch && <><Circle cx={xFor(smc.choch.index)} cy={yForPrice(smc.choch.price)} r="4" fill={palette.amber} /><SvgText x={xFor(smc.choch.index) - 10} y={yForPrice(smc.choch.price) - 9} fill={palette.amber} fontSize="10">CHOCH</SvgText></>}
        {smc.bos && <><SvgText x={width - 82} y="42" fill={palette.green} fontSize="11">TP1 23,260</SvgText><SvgText x={width - 82} y="29" fill={palette.green} fontSize="11">TP2 23,350</SvgText></>}
      </>}
      <Line x1="0" x2={width} y1="228" y2="228" stroke={palette.line} />
      {candles.map((c, i) => <Rect key={`v${i}`} x={18 + i * (candleWidth + 5)} y={292 - c.volume * 0.9} width={candleWidth} height={c.volume * 0.9} fill={c.close < c.open ? palette.green : palette.red} opacity="0.45" />)}
      <SvgText x="5" y="242" fill={palette.muted} fontSize="9">成交量</SvgText>
    </Svg>
  );
}

export default function App() {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(instruments[0]);
  const [timeframe, setTimeframe] = useState('15分');
  const [book, setBook] = useState<'ask' | 'bid'>('ask');
  const [showFib, setShowFib] = useState(true);
  const [showSmc, setShowSmc] = useState(true);
  const [showTriangle, setShowTriangle] = useState(true);
  const [sma, setSma] = useState('20');
  const [showConnection, setShowConnection] = useState(false);
  const [bridgeUrl, setBridgeUrl] = useState('http://127.0.0.1:8765');
  const [connectionStatus, setConnectionStatus] = useState('尚未測試');
  const [connectionBusy, setConnectionBusy] = useState(false);
  const testKgiConnection = async () => {
    setConnectionBusy(true);
    setConnectionStatus('正在檢查橋接服務…');
    try {
      const health = await fetch(`${bridgeUrl.replace(/\/$/, '')}/health`);
      if (!health.ok) throw new Error(`健康檢查 HTTP ${health.status}`);
      setConnectionStatus('橋接服務可連線，正在啟動凱基登入…');
      const start = await fetch(`${bridgeUrl.replace(/\/$/, '')}/api/start`, { method: 'POST' });
      const body = await start.json();
      if (!start.ok || !body.ok) throw new Error(body.message || body.error || `登入 HTTP ${start.status}`);
      setConnectionStatus('凱基登入成功，台股／期貨行情訂閱已啟動');
    } catch (error) {
      setConnectionStatus(`測試失敗：${error instanceof Error ? error.message : '請確認橋接服務與 CA 環境'}`);
    } finally {
      setConnectionBusy(false);
    }
  };
  const filtered = useMemo(() => instruments.filter((x) => `${x.symbol}${x.name}`.toLowerCase().includes(query.toLowerCase())), [query]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={styles.eyebrow}>MARKET LENS  /  LIVE SIMULATION</Text><Text style={styles.title}>交易雷達</Text></View><View style={styles.headerActions}><Pressable onPress={() => setShowConnection(!showConnection)} style={styles.connectButton}><Text style={styles.connectButtonText}>⌁ 凱基連線</Text></Pressable><View style={styles.live}><View style={styles.dot} /><Text style={styles.liveText}>模擬連線</Text></View></View></View>
        {showConnection && <View style={styles.connectionPanel}><View style={styles.connectionTitleRow}><View><Text style={styles.panelTitle}>凱基登入測試</Text><Text style={styles.connectionSubtitle}>台股＋國內期貨｜只讀行情模式</Text></View><Text style={styles.lock}>帳密不進 App</Text></View><Text style={styles.stepText}>1　先在安裝凱基 CA 與 kgisuperpy 的電腦啟動 bridge/server.py</Text><Text style={styles.stepText}>2　輸入本機橋接服務網址，再按「測試登入」</Text><Text style={styles.stepText}>3　登入成功後，App 才會取得報價、五檔與 15 分 K</Text><TextInput value={bridgeUrl} onChangeText={setBridgeUrl} autoCapitalize="none" autoCorrect={false} style={styles.bridgeInput} placeholder="http://127.0.0.1:8765" placeholderTextColor={palette.muted} /><Pressable onPress={testKgiConnection} disabled={connectionBusy} style={[styles.testButton, connectionBusy && styles.testButtonDisabled]}><Text style={styles.testButtonText}>{connectionBusy ? '測試中…' : '測試登入凱基'}</Text></Pressable><Text style={[styles.connectionStatus, connectionStatus.includes('成功') ? { color: palette.green } : connectionStatus.includes('失敗') ? { color: palette.red } : null]}>{connectionStatus}</Text><Text style={styles.securityNote}>安全提醒：凱基帳號、密碼、身分證字號與 CA 憑證只放在 bridge 所在電腦的環境設定，App 不會要求或儲存這些資料。</Text></View>}
        <View style={styles.searchRow}><TextInput value={query} onChangeText={setQuery} placeholder="搜尋商品：股票、期貨、金屬、匯率…" placeholderTextColor={palette.muted} style={styles.search} /><Text style={styles.searchIcon}>⌕</Text></View>
        {query.length > 0 && <View style={styles.searchResults}>{filtered.map((item) => <Pressable key={item.symbol} onPress={() => { setSelected(item); setQuery(''); }} style={styles.result}><Text style={styles.resultSymbol}>{item.symbol}</Text><Text style={styles.resultName}>{item.name}</Text><Text style={styles.resultPrice}>{item.price}</Text></Pressable>)}</View>}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.watchlist}>{instruments.map((item, i) => <Pressable key={item.symbol} onPress={() => setSelected(item)} style={[styles.watchCard, selected.symbol === item.symbol && styles.watchCardActive]}><View style={styles.watchTop}><Text style={styles.watchSymbol}>{item.symbol}</Text><MiniSparkline positive={item.color === palette.green} /></View><Text style={styles.watchName}>{item.name}</Text><Text style={styles.watchPrice}>{item.price}</Text><Text style={[styles.watchChange, { color: item.color }]}>{item.change}  {item.pct}</Text></Pressable>)}</ScrollView>
        <View style={styles.instrumentHeader}><View><Text style={styles.instrumentName}>{selected.name} <Text style={styles.instrumentSymbol}>{selected.symbol}</Text></Text><Text style={styles.instrumentPrice}>{selected.price} <Text style={styles.up}>+126  +0.55%</Text></Text></View><View style={styles.marketStatus}><Text style={styles.statusLabel}>盤中</Text><Text style={styles.statusTime}>10:42:18</Text></View></View>
        <View style={styles.toolbar}><View style={styles.segment}>{['1分', '5分', '15分', '1小時', '日線'].map((t) => <Pressable key={t} onPress={() => setTimeframe(t)} style={[styles.segmentButton, timeframe === t && styles.segmentActive]}><Text style={[styles.segmentText, timeframe === t && styles.segmentTextActive]}>{t}</Text></Pressable>)}</View><Text style={styles.chartType}>⋮  K線</Text></View>
        <View style={styles.chartPanel}><View style={styles.chartLegend}><Text style={[styles.legend, { color: palette.cyan }]}>● 價格</Text><Text style={[styles.legend, { color: palette.violet }]}>━ SMA({sma})</Text><Text style={[styles.legend, { color: palette.amber }]}>┄ 費波</Text><Text style={[styles.legend, { color: palette.cyan }]}>⌁ 三角收斂</Text></View><Chart showFib={showFib} showSmc={showSmc} showTriangle={showTriangle} /></View>
        <View style={styles.controlPanel}><Text style={styles.panelTitle}>分析圖層</Text><View style={styles.controlLine}><Text style={styles.controlLabel}>SMA 週期</Text><TextInput value={sma} onChangeText={setSma} keyboardType="number-pad" style={styles.smallInput} /><Text style={styles.controlHint}>主力成本：每日開盤 15分 K = (開 + 高 + 低) / 3</Text></View><View style={styles.chips}><Pressable onPress={() => setShowFib(!showFib)} style={[styles.chip, showFib && styles.chipActive]}><Text style={styles.chipText}>⌁ 費波黃金切割率</Text></Pressable><Pressable onPress={() => setShowTriangle(!showTriangle)} style={[styles.chip, showTriangle && styles.chipActiveCyan]}><Text style={styles.chipText}>△ Symmetrical Triangle</Text></Pressable><Pressable onPress={() => setShowSmc(!showSmc)} style={[styles.chip, showSmc && styles.chipActiveViolet]}><Text style={styles.chipText}>◈ SMC：CHOCH / OB / BOS / FVG</Text></Pressable><View style={styles.chip}><Text style={styles.chipText}>成本 23,112</Text></View></View></View>
        <View style={styles.orderHeader}><Text style={styles.panelTitle}>市場深度</Text><View style={styles.orderTabs}><Pressable onPress={() => setBook('ask')} style={[styles.orderTab, book === 'ask' && styles.orderTabAsk]}><Text style={styles.orderTabText}>委賣</Text></Pressable><Pressable onPress={() => setBook('bid')} style={[styles.orderTab, book === 'bid' && styles.orderTabBid]}><Text style={styles.orderTabText}>委買</Text></Pressable></View></View>
        <View style={styles.orderBook}><View style={styles.orderHead}><Text>價格</Text><Text>掛單量</Text><Text>累計</Text></View>{[0, 1, 2, 3, 4].map((i) => <View key={i} style={styles.orderRow}><View style={[styles.depth, { width: `${70 - i * 11}%`, backgroundColor: book === 'ask' ? palette.red : palette.green }]} /><Text style={styles.orderPrice}>{book === 'ask' ? (23192 - i * 2).toLocaleString() : (23182 - i * 2).toLocaleString()}</Text><Text style={styles.orderQty}>{[128, 86, 244, 92, 181][i]}</Text><Text style={styles.orderTotal}>{[128, 214, 458, 550, 731][i]}</Text></View>)}<View style={styles.midPrice}><Text>最新成交　23,184　 <Text style={styles.up}>+126</Text></Text></View>{[0, 1, 2, 3, 4].map((i) => <View key={`b${i}`} style={styles.orderRow}><View style={[styles.depth, { width: `${58 - i * 9}%`, backgroundColor: palette.green }]} /><Text style={styles.orderPrice}>{(23182 - i * 2).toLocaleString()}</Text><Text style={styles.orderQty}>{[301, 146, 88, 214, 106][i]}</Text><Text style={styles.orderTotal}>{[301, 447, 535, 749, 855][i]}</Text></View>)}</View>
        <View style={styles.footer}><Text>資料來源：本地模擬行情</Text><Text>READY FOR API</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: palette.bg }, container: { padding: 16, paddingBottom: 34 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }, headerActions: { alignItems: 'flex-end', gap: 7 }, eyebrow: { color: palette.cyan, fontSize: 10, letterSpacing: 1.3, fontWeight: '700' }, title: { color: palette.text, fontSize: 30, fontWeight: '800', marginTop: 4 }, connectButton: { borderWidth: 1, borderColor: palette.cyan, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: '#102b32' }, connectButtonText: { color: palette.cyan, fontSize: 11, fontWeight: '800' }, live: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#112f2d', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 20, marginTop: 4 }, dot: { width: 7, height: 7, backgroundColor: palette.green, borderRadius: 5, marginRight: 6 }, liveText: { color: palette.green, fontSize: 11, fontWeight: '700' }, connectionPanel: { backgroundColor: '#102a34', borderColor: palette.cyan, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 14 }, connectionTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 9 }, connectionSubtitle: { color: palette.muted, fontSize: 11, marginTop: 3 }, lock: { color: palette.green, fontSize: 10, fontWeight: '800' }, stepText: { color: palette.text, fontSize: 11, lineHeight: 18 }, bridgeInput: { height: 42, marginTop: 12, borderWidth: 1, borderColor: palette.line, borderRadius: 8, color: palette.text, backgroundColor: palette.bg, paddingHorizontal: 11, fontSize: 12 }, testButton: { backgroundColor: palette.cyan, borderRadius: 8, alignItems: 'center', paddingVertical: 11, marginTop: 9 }, testButtonDisabled: { opacity: 0.55 }, testButtonText: { color: palette.bg, fontWeight: '900', fontSize: 12 }, connectionStatus: { color: palette.amber, fontSize: 11, lineHeight: 17, marginTop: 10 }, securityNote: { color: palette.muted, fontSize: 10, lineHeight: 16, marginTop: 10 }, searchRow: { position: 'relative', marginBottom: 13 }, search: { height: 46, borderRadius: 12, borderWidth: 1, borderColor: palette.line, backgroundColor: palette.panel, paddingHorizontal: 15, paddingRight: 42, color: palette.text, fontSize: 13 }, searchIcon: { position: 'absolute', right: 15, top: 8, color: palette.cyan, fontSize: 27 }, searchResults: { position: 'absolute', zIndex: 10, top: 126, left: 16, right: 16, backgroundColor: '#14303a', borderRadius: 12, borderWidth: 1, borderColor: palette.cyan, padding: 6 }, result: { flexDirection: 'row', alignItems: 'center', padding: 11, borderBottomWidth: 1, borderBottomColor: palette.line }, resultSymbol: { color: palette.text, fontWeight: '800', width: 65 }, resultName: { color: palette.muted, flex: 1 }, resultPrice: { color: palette.cyan, fontWeight: '700' }, watchlist: { gap: 10, paddingBottom: 18 }, watchCard: { width: 145, padding: 12, backgroundColor: palette.panel, borderWidth: 1, borderColor: palette.line, borderRadius: 12 }, watchCardActive: { borderColor: palette.cyan, backgroundColor: '#102b32' }, watchTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, watchSymbol: { color: palette.text, fontSize: 13, fontWeight: '800' }, watchName: { color: palette.muted, fontSize: 11, marginTop: 2 }, watchPrice: { color: palette.text, fontSize: 17, fontWeight: '800', marginTop: 8 }, watchChange: { fontSize: 11, fontWeight: '700', marginTop: 3 }, instrumentHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 2, marginBottom: 14 }, instrumentName: { color: palette.text, fontSize: 19, fontWeight: '800' }, instrumentSymbol: { color: palette.muted, fontSize: 12, fontWeight: '500' }, instrumentPrice: { color: palette.text, fontSize: 26, fontWeight: '800', marginTop: 5 }, up: { color: palette.green, fontSize: 13, fontWeight: '700' }, marketStatus: { alignItems: 'flex-end' }, statusLabel: { color: palette.green, fontWeight: '800', fontSize: 12 }, statusTime: { color: palette.muted, fontSize: 11, marginTop: 4 }, toolbar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }, segment: { flexDirection: 'row', backgroundColor: palette.panel, borderRadius: 8, padding: 3 }, segmentButton: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 6 }, segmentActive: { backgroundColor: palette.cyan }, segmentText: { color: palette.muted, fontSize: 11, fontWeight: '700' }, segmentTextActive: { color: palette.bg }, chartType: { color: palette.muted, fontSize: 12 }, chartPanel: { backgroundColor: palette.panel, borderRadius: 14, borderWidth: 1, borderColor: palette.line, paddingTop: 10, paddingHorizontal: 6, overflow: 'hidden' }, chartLegend: { flexDirection: 'row', gap: 15, paddingLeft: 9, paddingBottom: 1 }, legend: { fontSize: 10, fontWeight: '700' }, controlPanel: { backgroundColor: palette.panel, borderRadius: 14, padding: 14, marginTop: 12, borderWidth: 1, borderColor: palette.line }, panelTitle: { color: palette.text, fontSize: 14, fontWeight: '800' }, controlLine: { flexDirection: 'row', alignItems: 'center', marginTop: 12 }, controlLabel: { color: palette.muted, fontSize: 12, marginRight: 8 }, smallInput: { color: palette.text, backgroundColor: palette.panel2, width: 46, height: 30, borderRadius: 6, textAlign: 'center', borderWidth: 1, borderColor: palette.line, fontWeight: '800' }, controlHint: { color: palette.muted, fontSize: 10, marginLeft: 10, flex: 1 }, chips: { flexDirection: 'row', gap: 7, marginTop: 13, flexWrap: 'wrap' }, chip: { borderColor: palette.line, borderWidth: 1, borderRadius: 7, paddingHorizontal: 9, paddingVertical: 7, backgroundColor: palette.panel2 }, chipActive: { borderColor: palette.amber, backgroundColor: '#332e1c' }, chipActiveCyan: { borderColor: palette.cyan, backgroundColor: '#102f38' }, chipActiveViolet: { borderColor: palette.violet, backgroundColor: '#25233c' }, chipText: { color: palette.text, fontSize: 11, fontWeight: '700' }, orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 18, marginBottom: 9 }, orderTabs: { flexDirection: 'row', backgroundColor: palette.panel, borderRadius: 8, padding: 3 }, orderTab: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 6 }, orderTabAsk: { backgroundColor: '#3b232b' }, orderTabBid: { backgroundColor: '#17352f' }, orderTabText: { color: palette.text, fontSize: 11, fontWeight: '800' }, orderBook: { backgroundColor: palette.panel, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: palette.line }, orderHead: { flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 7, borderBottomWidth: 1, borderBottomColor: palette.line, color: palette.muted }, orderRow: { height: 29, flexDirection: 'row', alignItems: 'center', position: 'relative' }, depth: { position: 'absolute', right: 0, height: 20, opacity: 0.12, borderRadius: 3 }, orderPrice: { color: palette.text, flex: 1, fontSize: 12, fontWeight: '700' }, orderQty: { color: palette.muted, width: 75, textAlign: 'right', fontSize: 12 }, orderTotal: { color: palette.muted, width: 75, textAlign: 'right', fontSize: 12 }, midPrice: { marginVertical: 5, paddingVertical: 8, borderTopWidth: 1, borderBottomWidth: 1, borderColor: palette.line, alignItems: 'center' }, midPriceText: { color: palette.text, fontSize: 12 }, footer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 18 }, footerText: { color: palette.muted, fontSize: 10 },
});
