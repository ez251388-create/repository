# Android APK 建置

專案已加入 GitHub Actions：`.github/workflows/build-apk.yml`。

## GitHub Actions 雲端建置

將專案推送到 GitHub 後，Workflow 會在以下情況自動執行：

- 推送到 `main` 或 `master`
- 建立或更新 Pull Request
- 在 GitHub Actions 頁面按 **Run workflow** 手動執行

完成後開啟該次 Workflow，在 **Artifacts** 下載 `market-lens-debug-apk-*`。這是可直接安裝到 Android 的 debug APK。

此 Workflow 會使用 Node.js 22、Java 17、Android API 36，執行 `expo prebuild` 後用 Gradle 編譯，不需要把 `android/` 原生目錄提交到 Git。

## 本機建置

本機必須先安裝 Node.js 22、Java 17、Android SDK、platform-tools、Android API 36 與 Build Tools 36.0.0，並設定 `ANDROID_HOME` 或 `ANDROID_SDK_ROOT`。

```bash
npm install
npm run build:apk
```

或直接執行：

```bash
bash scripts/build-apk.sh
```

APK 會輸出在專案根目錄，檔名類似 `market-lens-debug-20261006-215700.apk`。

## 安裝 APK

手機開啟 USB 偵錯並連接電腦後：

```bash
adb install -r market-lens-debug-*.apk
```

也可以把 APK 傳到手機後直接點擊安裝。此版本是 debug build，僅供介面與功能測試，不是正式上架用的 signed release AAB。

## 安全提醒

GitHub Actions 不需要凱基帳號、密碼或 CA 憑證即可編譯介面。凱基登入測試仍由本機 `kgi-bridge/server.py` 處理，不要把 `.env`、憑證或 API 秘密放進 GitHub repository。
